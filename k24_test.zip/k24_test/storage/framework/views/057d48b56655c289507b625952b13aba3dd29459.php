<div class="sidebar" data-color="white" data-active-color="danger">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
      <div class="logo">
        <a href="#" class="simple-text logo-mini">
          <div class="logo-image-small">
          <img src="<?php echo e(url('storage/profile-pic')); ?>/<?php echo e(Auth::user()->avatar); ?>" alt="<?php echo e(Auth::user()->name); ?>"/>
          </div>
        </a>
        <a href="#" class="simple-text logo-normal">
          <?php echo e(Auth::user()->name); ?><br>
          <?php echo e(Auth::user()->email); ?>

          <!-- <div class="logo-image-big">
            <img src="../assets/img/logo-big.png">
          </div> -->
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li <?php echo e(Route::is('home')? 'class=active':''); ?>>
            <a href="<?php echo e(route('home')); ?>">
              <i class="nc-icon nc-bank"></i>
              <p>Dashboard</p>
            </a>
          </li>

          <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
          <li <?php echo e(Route::is('permissions.index')||Route::is('permissions.create')||Route::is('permissions.edit')||Route::is('roles.index')||Route::is('roles.create')||Route::is('roles.edit')||Route::is('users.index')||Route::is('users.create')||Route::is('users.edit')? 'class=active':''); ?>>
          <a data-toggle="collapse" href="#users" aria-expanded="false" class="collapsed">
              <i class="nc-icon nc-bank"></i>
              <p>Manage Users</p>
              <b class="caret"></b>
          </a>
        <div class="collapse" id="users" aria-expanded="false" style="height: 0px;">
          <ul class="nav">
          <li <?php echo e(Route::is('permissions.index')||Route::is('permissions.create')||Route::is('permissions.edit')? 'class=active':''); ?>>
              <a href="<?php echo e(route('permissions.index')); ?>">
              <i class="nc-icon nc-single-02"></i>
                  <p>Permissions</p>
              </a>
            </li>
            <li <?php echo e(Route::is('roles.index')||Route::is('roles.create')||Route::is('roles.edit')? 'class=active':''); ?>>
              <a href="<?php echo e(route('roles.index')); ?>">
              <i class="nc-icon nc-single-02"></i>
                  <p>Roles</p>
              </a>
            </li>
            <li <?php echo e(Route::is('users.index')||Route::is('users.create')||Route::is('users.edit')? 'class=active':''); ?>>
              <a href="<?php echo e(route('users.index')); ?>">
              <i class="nc-icon nc-single-02"></i>
                  <p>Users</p>
              </a>
            </li>
          </ul>
        </div>
      </li>

      <?php endif; ?>

      <li <?php echo e(Route::is('profile.index')? 'class=active':''); ?>>
        <a href="<?php echo e(route('profile.index')); ?>">
          <i class="nc-icon nc-circle-10"></i>
          <p>User Profile</p>
        </a>
      </li>

        </ul>
      </div>
</div>
<?php /**PATH C:\xampp\htdocs\Laravel7.x-Roles-Permissions-Admin-Paper-Dashboard-bootstrap4-master\resources\views/layouts/partials/side-bar.blade.php ENDPATH**/ ?>