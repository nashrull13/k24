<?php $__env->startSection('title'); ?>
	Roles
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('index'); ?>
        <div class="content">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="">
                            <h3>Roles</h3>
                            <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-success btn-sm">Add New</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dt-mant-table">
                                    <thead>
                                        <tr>
                                        	<th>Id</th>
                                            <th>Name</th>
                                            <th>Permissions</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    	<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                        	<td><?php echo e($row->id); ?></td>
                                        	<td><?php echo e($row->name); ?></td>
                                            <td>
                                                <?php $__currentLoopData = $row->permissions()->pluck('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($permission); ?>,
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                        	<td>
                                                <div style="display:flex;">
                                                    <a href="<?php echo e(route('roles.edit',$row->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                                        &nbsp;
                                                    <form id="delete_form<?php echo e($row->id); ?>" method="POST" action="<?php echo e(route('roles.destroy',$row->id)); ?>" onclick="return confirm('Are you sure?')">
                                                        <?php echo csrf_field(); ?>
                                                        <input name="_method" type="hidden" value="DELETE">
                                                        <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                                                    </form>
                                                </div>
                                        	</td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel7.x-Roles-Permissions-Admin-Paper-Dashboard-bootstrap4-master\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>